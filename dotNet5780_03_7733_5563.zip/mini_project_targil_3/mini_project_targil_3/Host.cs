﻿
//michael shachor 206197733
//Shimon Mizrahi 203375563

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mini_project_targil_3
{
    //Host class presentation:
    public class Host
    {
        //propertis:
        public string HostName { get; set; }
        public List<HostingUnit> Units { get; set; }
        //public override string ToString()
        //{
        //    return this.HostName;
        //}
    }

}
